import { Component,ViewChild } from '@angular/core';
import {  NavController,Slides} from 'ionic-angular';
/**
 * Generated class for the MyCardsComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'my-cards',
  templateUrl: 'my-cards.html'
})
export class MyCardsComponent {
  showSkip = true;
  @ViewChild(Slides) slides: Slides;

    public cards: any;
    constructor(public navCtrl: NavController) {

      this.cards = [
        {
          state: 'ON',
          logo: "assets/card-img/visa.png",
          a: 1234,
          b: 5522,
          c: 8432,
          d: 2264,
          expires: '7/22',
          bank: 'Bank of America'
        },
        {
          state: 'OFF',
          logo: "assets/card-img/visa.png",
          a: 1234,
          b: 5321,
          c: 8283,
          d: 9271,
          expires: '8/24',
          bank: 'JPMorgan'
        },
        {
          state: 'OFF',
          logo: "assets/card-img/visa.png",
          a: 8685,
          b: 2445,
          c: 9143,
          d: 7846,
          expires: '11/21',
          bank: 'CityBank'
        }
      ];

    }

  }

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import {Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import {Observable} from "rxjs/Rx";
import { GlobalVarsProvider } from '../../providers/providers';
// import { Network } from '@ionic-native/network';
// import { Platform } from 'ionic-angular';

// declare var Connection;
@Injectable()
export class ClientdataProvider {
   
    // url = 'https://1ace10d2.ngrok.io/helaApi/hela/helaapi';
    // url = 'http://192.168.20.179:8080/helaApi/hela/helaapi';
    url = 'http://localhost:8383/helaApi/hela/helaapi';
   google_url = 'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=-6.805293,39.252749&radius=1500&type=club&keyword=event&key=AIzaSyAD941hRyogzLW-7f7RBRXsOKeK5kVIgMo';
    
token: any;
    myhmac: any;    
    key: string = "ab765f9ewrt5hgf";
    iv: string = "ab765f987654321098765a98765abcd0";

    constructor(public http: Http,public globalVars:GlobalVarsProvider) {
        
    }

    getGet( user: any ) {
        return this.http.get(this.google_url)
            .timeout(20000)
            .map(
            ( data: Response ) =>
                data.json()
            )
            .catch(this.handleError);

    }
    getPost( user: any ) {
        
        let headers = new Headers( {
    'Content-Type': 'application/json',
        'token':this.token,
        'X-FORWARDED_FOR':this.myhmac
        } );
      
       user.version = '0.01';
       user.lang = 'en';
       user.channel = 'APP';
      // user.device_id = this.globalVars.getUIID();
       user.device_id = 'd705e7f2d7b7aff';
        //var body = this.JSONify( user );
        var body = JSON.stringify( user );
      console.log( body );
		  let options = new RequestOptions({ headers: headers });
        return this.http.post(this.url, body, options)
            .timeout(20000)
            .map(
            ( data: Response ) =>
                data.json()
            )
            .catch(this.handleError);

    }



    JSONify( data ) {
    //   var source = JSON.stringify( data );
    //   let encypted = this.globalVars.testenc( source );
    //   return JSON.stringify( { data: encypted } );
    }


    sendData(user: any) {return this.getPost(user);}
    turnUp(user: any) {return this.getGet(user);}




    private handleError(error: any) {
        console.log(error);
        return Observable.throw(error.json());
    }
}


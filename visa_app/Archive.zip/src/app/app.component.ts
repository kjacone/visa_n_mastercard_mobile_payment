import { Component, ViewChild } from '@angular/core';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { TranslateService } from '@ngx-translate/core';
import { Config, Nav, Platform } from 'ionic-angular';
// import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Device } from '@ionic-native/device';
import { GlobalVarsProvider } from '../providers/global-vars/global-vars';
import { Contacts } from '@ionic-native/contacts';
import { Storage } from '@ionic/storage';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  // rootPage = 'TutorialPage';
  // rootPage = 'ThirdPage';
  rootPage='WalletPage';
  // rootPage ='LoginPage';
  //rootPage='BuyTicketPage';
  //rootPage = 'FlightTicketPage';
  //rootPage = 'MainPage';

  @ViewChild(Nav) nav: Nav;
  constructor( private translate: TranslateService, platform: Platform, private config: Config, public globalVars: GlobalVarsProvider, public device: Device ,
    private storage: Storage,private statusBar: StatusBar, private splashScreen: SplashScreen ) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      // this.statusBar.styleDefault();
      // this.statusBar.overlaysWebView(false);
      // this.statusBar.backgroundColorByHexString('#ad1518');
      // this.splashScreen.hide();

      statusBar.styleDefault();
      globalVars.checkInternet();
      //  clientData.getAll();
      this.splashScreen.hide();
      // globalVars.uuid  =  device.uuid ;
    } );
    console.log( 'Hello main Provider' );
    // this.globalVars.showTimeout();
    // this.storage.clear();
    this.storage.get( 'local' ).then(( val ) => {
      if ( val ) {
        // console.log("Storage Response: ", val );
        let decrypted = this.globalVars.testdec( val );
        let decryptedJson = JSON.parse( decrypted );
        this.globalVars.Username = decryptedJson.mobile ;
        this.globalVars.country = decryptedJson.country;
        this.storage.get( 'pin' ).then(( val ) => {
          if ( val ) {
            // console.log("Storage Response: ", val );
            let decrypted = this.globalVars.testdec( val );
            let decryptedJson = JSON.parse( decrypted );
            this.globalVars.Username = decryptedJson.mobile;
            let pin = decryptedJson.pin;
            this.rootPage = 'WalletPage'
          } else {
            this.rootPage = 'LoginPage'
          }
        } );


      } else {
        this.rootPage = 'LoginPage'
      }
    } );


    this.initTranslate();
  }

  initTranslate() {
    // Set the default language for translation strings, and the current language.
    this.translate.setDefaultLang('en');
    const browserLang = this.translate.getBrowserLang();

    if (browserLang) {
      if (browserLang === 'zh') {
        const browserCultureLang = this.translate.getBrowserCultureLang();

        if (browserCultureLang.match(/-CN|CHS|Hans/i)) {
          this.translate.use('zh-cmn-Hans');
        } else if (browserCultureLang.match(/-TW|CHT|Hant/i)) {
          this.translate.use('zh-cmn-Hant');
        }
      } else {
        this.translate.use(this.translate.getBrowserLang());
      }
    } else {
      this.translate.use('en'); // Set your language here
    }

    this.translate.get(['BACK_BUTTON_TEXT']).subscribe(values => {
      this.config.set('ios', 'backButtonText', values.BACK_BUTTON_TEXT);
    });
  }


  openPage(page) {
      this.nav.push(page);

  }


   logout() {
     //this.platform.exitApp();
     this.nav.push('LoginPage');
   }


}

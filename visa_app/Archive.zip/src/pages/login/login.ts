import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { IonicPage, NavController, ToastController } from 'ionic-angular';
import { GlobalVarsProvider } from '../../providers/global-vars/global-vars';
// import { AlertServiceProvider } from '../../providers/providers';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {

  countries: any = [ { name: "Tanzania", code: "255" }];
  data: any = {type:'login',mobile:'',country:''}
  error: number = 0;
  sel: boolean = true;
  checked:boolean = false;

  constructor(public navCtrl: NavController,
    public globalVars: GlobalVarsProvider,
    public toastCtrl: ToastController,
    public translateService: TranslateService ) {

    this.data.mobile = this.globalVars.trimPhome( globalVars.Username );
    this.data.country = this.countries[0].code;
    this.data.mmobile = " (+" + this.data.country + ") 0"+ this.data.mobile;

  }

  ionViewDidEnter() {
    console.log( "LoginPage" );
  }

  doLogin() {
    if(this.checked){
    this.error = 0;
    this.data.mobile = this.data.country + this.globalVars.trimPhome( this.data.mmobile);
    if ( this.data.country == "" || this.data.country == undefined ) {
      this.error = 1;
    } else if ( this.data.mobile == "" || this.data.mobile == undefined || this.data.mobile.length < 12 ) {
      this.error = 2;
    } else {
      this.navCtrl.push( 'OtpPage', { data: this.data.mobile } );
    }
  }
  }

  setNumber() {
    this.data.mmobile = "";
    this.data.mmobile = "(+" + this.data.country + ") 0" ;
  }


  register(){
    this.navCtrl.push('SignupPage');
  }
}

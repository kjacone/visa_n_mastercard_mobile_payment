import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AndroidPermissions } from '@ionic-native/android-permissions';
import { App, Platform, Nav, Config, ModalController, AlertController } from 'ionic-angular';
import { CallNumber } from '@ionic-native/call-number';
import { GlobalVarsProvider } from '../../providers/global-vars/global-vars';
import { AlertServiceProvider } from '../../providers/alert-service/alert-service';
import { ClientdataProvider } from '../../providers/clientdata/clientdata';

/**
 * Generated class for the OtpPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
declare var SMS: any;
@IonicPage()
@Component({
  selector: 'page-otp',
  templateUrl: 'otp.html',
  } )

export class OtpPage {
  messages: any = [];
  account: any = { tel: "2557247279999" }
  data: any = { type: "otp" ,code:"0100",mobile:""};
  err: any = {};
  error: number = 0;
  constructor( public navCtrl: NavController, public navParams: NavParams, public app: App, public globalVars: GlobalVarsProvider, public alertService: AlertServiceProvider,
    public modalCtrl: ModalController, public clientdata: ClientdataProvider,
    public androidPermissions: AndroidPermissions, public platform: Platform, public callNumber: CallNumber ) {
    this.data.mobile = navParams.get( 'data' );
    this.err = globalVars.general.err;
    // console.log( this.err );
    //this.submittt();
  }

  call() {
    this.callNumber.callNumber( "*106#", true )
      .then( res => console.log( 'Launched dialer!', res ) )
      .catch( err => console.log( 'Error launching dialer', err ) );
  }


  submittt() {
    if ( "0100" == "0100" ) {
      this.alertService.errorPop( "PinchangePage", "your confirmation was done successfully", true );
    } else {
      this.alertService.errorPop( "", "Incorrect Confirmation Code", true );
    }
  }

  submitted() {
    this.alertService.showDefaultLoading();
    this.clientdata.sendData( this.data )
      .subscribe( data => {
        if ( data.length != 0 ) {
          console.log( "Response: ", data );
          this.alertService.dismissDefaultLoading();
          if ( data.success ) {
            if ( data.code == "0100" ) {
              this.alertService.errorPop( "PinchangePage", data.message, true  );
            } else {
              this.alertService.errorPop( "", "Incorrect Confirmation Code", true  );
            }


          } else if ( !data.success ) {

            this.alertService.errorPop( "", data.message, true );

          } else {
            this.navCtrl.setRoot( this.navCtrl.getPrevious() );
            this.alertService.errorPop( "", this.err.tech, true  );
          }
        } else {
          this.navCtrl.setRoot( this.navCtrl.getPrevious() );
          console.log( " timeout" );
          this.alertService.dismissDefaultLoading();
          this.navCtrl.setRoot( this.navCtrl.getPrevious() );
          this.alertService.errorPop( "", this.err.timeout, true  );
        }
      }, error => {
        this.alertService.dismissDefaultLoading();
        this.navCtrl.setRoot( this.navCtrl.getPrevious() );
        this.alertService.errorPop( "", this.err.conn, true  );
      } );
  }




  ionViewDidEnter() {

    // this.platform.ready().then(( readySource ) => {

    //   if ( SMS ) SMS.startWatch(() => {
    //     console.log( 'watching started' );
    //     this.ReadListSMS();
    //   }, Error => {
    //     console.log( 'failed to start watching' );
    //   } );

    //   document.addEventListener( 'onSMSArrive', ( e: any ) => {
    //     var sms = e.data;
    //     // sms = JSON.parse( sms );
    //     //  console.log( sms );
    //     // this.readConfirmationCode( sms );

    //   } );

    // } );
  }

  checkPermission() {
    this.androidPermissions.checkPermission
      ( this.androidPermissions.PERMISSION.READ_SMS ).then(
      success => {

        //if permission granted
        this.ReadListSMS();
      },
      err => {

        this.androidPermissions.requestPermission
          ( this.androidPermissions.PERMISSION.READ_SMS ).
          then( success => {
            this.ReadListSMS();
          },
          err => {
            alert( "cancelled" )
          } );
      } );

    this.androidPermissions.requestPermissions
      ( [ this.androidPermissions.PERMISSION.READ_SMS ] );

  }

  ReadListSMS() {

    this.platform.ready().then(( readySource ) => {

      let filter = {
        box: 'inbox', // 'inbox' (default), 'sent', 'draft'
        indexFrom: 0, // start from index 0
        maxCount: 20, // count of SMS to return each time
      };

      if ( SMS ) SMS.listSMS( filter, ( ListSms ) => {
        this.messages = ListSms;
        console.log( "My Sms", this.messages );
        this.readConfirmationCode();

      },

        Error => {
          console.log( 'error list sms: ' + Error );
        } );

    } );
  }

 checkMpesa( age ) {
   return age.address == "Vodacom";
}

  readConfirmationCode( ) {
  var a:any =  this.messages.find( this.checkMpesa);
    console.log( 'SMS Code: ' + a.body );
  }

  SendMySMS() {

    this.platform.ready().then(( readySource ) => {

      if ( SMS ) SMS.sendSMS( "+9112345", "msg", () => {
        console.log( "Sent" );
      }, Error => {
        console.log( "Error occurs" )
      } );
    } );

  }




  doLogin() {
    // this.alertService.showPin();
    this.navCtrl.push( 'PinchangePage' );
  }

}

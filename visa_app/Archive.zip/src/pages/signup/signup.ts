import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { IonicPage, NavController, ToastController, ModalController } from 'ionic-angular';
import { GlobalVarsProvider } from '../../providers/global-vars/global-vars';
import { AlertServiceProvider } from '../../providers/alert-service/alert-service';
import { ClientdataProvider } from '../../providers/clientdata/clientdata';
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html'
})
export class SignupPage {
  countries: any = [ { name: "Tanzania", code: "255" }, { name: "Kenya", code: "254" } ];
  data: any = { type:"register"};
  err: any = {};
  error: number = 0;

  constructor( public navCtrl: NavController, public globalVars: GlobalVarsProvider, public alertService: AlertServiceProvider,
    private storage: Storage,public modalCtrl: ModalController, public clientdata:ClientdataProvider) {

    this.err = globalVars.general.err;
    // this.alertService.showPin();
  }


  setNumber() {
    this.data.mobile = "";
    this.data.mobile = "(+" + this.data.country + ")0";
  }
  reg() {
  this.submit();
  }

  submit() {
    let message = "";
    let template = "<div>" + message + "</div>";
    let obj = { status: true, url: 'https://forum.ionicframework.com/' };
    let myModal = this.modalCtrl.create( 'AuthWebviewPage', {data: obj} );
    myModal.present();
    myModal.onDidDismiss( data => {
      this.navCtrl.push('WalletPage');
    } );
  }

  submitt() {
    this.globalVars.is_first_login = true;
    this.globalVars.Username = this.data.mobile;
    this.globalVars.country = this.data.country;
    let persist: any = { mobile: this.data.mobile, country: this.data.country }
    let encryptPersist = this.globalVars.testenc( JSON.stringify( persist ) );
    this.storage.set( 'local', encryptPersist );
    this.navCtrl.push( 'ReceiptPage', {
      data: {
        message: "Your registration request is being processed",
        style: 'wait',
        next: 'LoginPage'
      }
    } );
  }
  submitted() {
    this.alertService.showDefaultLoading( );
    this.clientdata.sendData( this.data )
      .subscribe( data => {
        if ( data.length != 0 ) {
          console.log( "Response: ",  data );
          this.alertService.dismissDefaultLoading();
          if ( data.success ) {
            this.globalVars.is_first_login = data.first_login;
            this.globalVars.Username = this.data.mobile;
            this.globalVars.country = this.data.country;
            let persist: any = { mobile: this.data.mobile, country: this.data.country }
            let encryptPersist = this.globalVars.testenc(JSON.stringify( persist ));
            this.storage.set( 'local', encryptPersist );
            this.navCtrl.push( 'ReceiptPage', {
              data: {
              message:data.message,
              style:'wait',
              next:'LoginPage'
            } } );
          } else if ( !data.success ) {

            this.navCtrl.push( 'ReceiptPage', {
              data: {
                message: data.message,
                style: 'error',
                next: ''
              }
            } );

          } else {
            this.navCtrl.setRoot( this.navCtrl.getPrevious() );
            this.alertService.errorPop( "", this.err.tech, true  );
          }
        } else {
          this.navCtrl.setRoot( this.navCtrl.getPrevious() );
          console.log( " timeout" );
          this.alertService.dismissDefaultLoading();
          this.navCtrl.setRoot( this.navCtrl.getPrevious() );
          this.alertService.errorPop( "", this.err.timeout, true  );
        }
      }, error => {
        this.alertService.dismissDefaultLoading();
        this.navCtrl.setRoot( this.navCtrl.getPrevious() );
        this.alertService.errorPop( "", this.err.conn, true  );
      } );
  }



}

import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { IonicPage, NavController, ToastController, ModalController,AlertController } from 'ionic-angular';
import { GlobalVarsProvider } from '../../providers/global-vars/global-vars';
import { AlertServiceProvider } from '../../providers/alert-service/alert-service';
import { ClientdataProvider } from '../../providers/clientdata/clientdata';
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
    selector: 'page-pinchange',
    templateUrl: 'pinchange.html'
})
export class PinchangePage {
  countries: any = [ { name: "Tanzania", code: "255" }, { name: "Kenya", code: "254" } ];
  data: any = { type:"pin_change"};
  err: any = {};
  error: number = 0;

  constructor( public navCtrl: NavController,public alertCtrl: AlertController , public globalVars: GlobalVarsProvider, public alertService: AlertServiceProvider,
    private storage: Storage,public modalCtrl: ModalController, public clientdata:ClientdataProvider) {

    this.err = globalVars.general.err;
    this.data.mobile = globalVars.Username;
    // this.alertService.errorPop( "", this.err.tech, false );
  }



  reg() {
    this.error = 0;
    this.data.mobile = this.data.country + this.globalVars.trimPhome( this.data.mobile );
    if ( this.data.pin == "" || this.data.pin == undefined ) {
      this.error = 1;
    } else if ( this.data.newpin != this.data.pin) {
      this.error = 2;
    } else {
      this.submit();
    }
  }

  submit() {
    let message = "this is a Secure PIN. Please do not share ";
    let template = "<div>" + message + "</div>";

    let obj = { template: template, pageTo: '', iscomplete: false };
    let myModal = this.modalCtrl.create( 'ConfirmModalPage', { data: obj } );
    myModal.present();
    myModal.onDidDismiss( data => {
      console.log( "Data =>" + data );
      if ( data ) {
        this.showPaymentPrompt();
      }
      else {

      }
    } );
  }

  register(){
    this.navCtrl.push('SignupPage');
  }

  showPaymentPrompt() {
     const prompt = this.alertCtrl.create({
       title: 'Payment ',
       message: "Add Card as a default mode of payment",

       buttons: [

         {
           text: 'Add Card ',
           handler: data => {
              this.register();
           }
         }
       ]
     });
     prompt.present();
   }

  submitted() {
         let persist: any = { pin: this.data.pin, pinstat: true }
            let encryptPersist = this.globalVars.testenc( JSON.stringify( persist ) );
            this.storage.set( 'pin', encryptPersist );
            this.navCtrl.push( 'ReceiptPage', {
              data: {
              message:"Your PIN was set successfully",
              style:'success',
              next:'WalletPage'
            } } );
  }
}

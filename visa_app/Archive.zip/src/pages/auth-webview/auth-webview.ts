import { Component } from '@angular/core';
import { IonicPage, NavParams, NavController, ViewController } from 'ionic-angular';
import { GlobalVarsProvider } from '../../providers/global-vars/global-vars';
import { DomSanitizer,SafeResourceUrl } from "@angular/platform-browser";


@IonicPage()
@Component({
  selector: 'page-auth-webview',
  templateUrl: 'auth-webview.html',
})
export class AuthWebviewPage {
  safeUrl:  SafeResourceUrl;
  sanitizer: DomSanitizer;
  inCardData: any = {
    url: "",
    status: ""
  };

  constructor(private dSanitizer: DomSanitizer,public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController,
    public globalVars: GlobalVarsProvider) {
    let data = navParams.get('data')
    this.sanitizer = dSanitizer;
     this.safeUrl =  this.sanitizer.bypassSecurityTrustResourceUrl(data.url+'/override-http-headers-default-settings-x-frame-options');
  }


  close() {
    this.viewCtrl.dismiss();
  }


}
